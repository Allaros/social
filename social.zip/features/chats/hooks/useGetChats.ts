import { useInfiniteQuery } from '@tanstack/react-query';
import { GetMyChatsParams } from '../types/chats.interface';
import { chatsApi } from '../api/chats';

export const useGetChats = (params?: Omit<GetMyChatsParams, 'cursor'>) => {
   return useInfiniteQuery({
      queryKey: ['chats', params],

      queryFn: ({ pageParam }) =>
         chatsApi.getMyChats({ ...params, cursor: pageParam }),

      initialPageParam: undefined as string | undefined,

      getNextPageParam: (lastPage) => lastPage.nextCursor ?? undefined,
   });
};
