import { chatsApi } from '@/features/chats/api/chats';
import {
   CreateDirectChatPayload,
   CreateGroupChatPayload,
} from '@/features/chats/types/chats.interface';
import { useLoader } from '@/features/loader/hooks/useLoader';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';

export const useCreateChat = () => {
   const queryClient = useQueryClient();
   const { showLoader, hideLoader } = useLoader();

   const invalidateChats = () => {
      queryClient.invalidateQueries({ queryKey: ['chats'], exact: false });
   };

   const createDirect = useMutation({
      mutationFn: (payload: CreateDirectChatPayload) =>
         chatsApi.createDirectChat(payload),
      onSuccess: invalidateChats,
      onError: () => toast.error('Не удалось создать чат'),
   });

   const createGroup = useMutation({
      mutationFn: (payload: CreateGroupChatPayload) =>
         chatsApi.createGroupChat(payload),
      onMutate: showLoader,
      onSettled: hideLoader,
      onSuccess: () => {
         invalidateChats();
         toast.success('Группа создана');
      },
      onError: () => toast.error('Не удалось создать группу'),
   });

   return { createDirect, createGroup };
};
