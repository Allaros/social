'use client';

import React from 'react';
import { useGetChats } from '../hooks/useGetChats';
import Chat from './Chat';

const ChatFeed = () => {
   const { data, fetchNextPage, hasNextPage, isFetching } = useGetChats();

   const chats = data?.pages.flatMap((page) => page.data) ?? [];
   return (
      <div>
         {chats.map((chat) => (
            <Chat />
         ))}
      </div>
   );
};

export default ChatFeed;
