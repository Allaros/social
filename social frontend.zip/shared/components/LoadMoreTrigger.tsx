import { useEffect, useRef } from 'react';

const LoadMoreTrigger = ({
   fetchNextPage,
   hasNextPage,
   isFetching,
}: {
   fetchNextPage: () => Promise<unknown>;
   hasNextPage: boolean;
   isFetching: boolean;
}) => {
   const ref = useRef<HTMLDivElement | null>(null);
   const lockRef = useRef(false);

   useEffect(() => {
      const observer = new IntersectionObserver((entries) => {
         const entry = entries[0];

         if (!entry.isIntersecting) return;
         if (!hasNextPage || isFetching || lockRef.current) return;

         lockRef.current = true;

         fetchNextPage().finally(() => {
            lockRef.current = false;
         });
      });

      if (ref.current) observer.observe(ref.current);

      return () => observer.disconnect();
   }, [hasNextPage, isFetching, fetchNextPage]);

   return <div ref={ref} style={{ height: 1 }} />;
};

export default LoadMoreTrigger;
