import type { NextConfig } from 'next';
const nextConfig: NextConfig = {
   images: {
      remotePatterns: [
         {
            protocol: 'https',
            hostname: 'lh3.googleusercontent.com',
         },
         {
            protocol: 'https',
            hostname: 'avatars.githubusercontent.com',
         },
         {
            protocol: 'https',
            hostname: 'cdn.discordapp.com',
         },
         {
            protocol: 'https',
            hostname: 'wkxvyhsgbdmqbvfphdej.supabase.co',
         },
      ],
   },
};

export default nextConfig;
