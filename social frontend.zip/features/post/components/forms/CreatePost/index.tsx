'use client';

import { Controller, useForm } from 'react-hook-form';
import PostEditor from './PostEditor';
import ImageUploader from './MediaUploader';

interface FormData {
   content: string;
   images: File[];
}

const allowedTypes = [
   'image/jpeg',
   'image/png',
   'image/webp',
   'video/mp4',
   'video/quicktime',
];

const CreatePostForm = () => {
   const { control, handleSubmit, setValue, watch } = useForm<FormData>({
      defaultValues: {
         content: '',
         images: [],
      },
   });

   const images = watch('images');

   const onsubmit = (data: FormData) => {
      console.log(data);
   };
   return (
      <form className="flex flex-col gap-4" onSubmit={handleSubmit(onsubmit)}>
         <Controller
            name="content"
            control={control}
            render={({ field }) => (
               <PostEditor value={field.value} onChange={field.onChange} />
            )}
         />
         <div className="relative">
            <ImageUploader
               media={images}
               onChange={(files) => setValue('images', files)}
               allowedTypes={allowedTypes}
               maxVideoMb={20}
               maxImageMb={10}
               maxFiles={10}
            />
            <button
               className="absolute top-0 right-0 z-10 text-neutralWhite-100 textBody-medium transition-colors bg-primary-900 px-5 py-0.75 rounded-[100px] cursor-pointer hover:bg-primary-800"
               type="submit"
            >
               Post
            </button>
         </div>
      </form>
   );
};

export default CreatePostForm;
