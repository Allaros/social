'use client';

import { PostResponse } from '../../types/post.responce';
import ActionHeader from './ActionHeader';
import CreateCommentForm from '@/features/comments/components/forms/CreateCommentForm';
import CommentsFeed from '@/features/comments/components/CommentsFeed';
import CommentIco from '@/public/icons/Comment.svg';
import Image from 'next/image';
import { useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import useMeasureHeight from '@/shared/hooks/useMeasureHeight';

const ActionBlock = ({ post }: { post: PostResponse }) => {
   const [isOpen, setIsOpen] = useState(false);

   const { height, ref } = useMeasureHeight();

   return (
      <div className="mt-8 px-8">
         <ActionHeader post={post} />

         <motion.div
            initial={false}
            animate={{
               height: isOpen ? height : 0,
               opacity: isOpen ? 1 : 0,
            }}
            transition={{
               height: { duration: 0.25 },
               opacity: { duration: 0.15 },
            }}
            className="overflow-hidden"
         >
            <div ref={ref}>
               <CreateCommentForm postId={post.id} />
               <CommentsFeed
                  postId={post.id}
                  authorUsername={post.author.username}
               />
            </div>
         </motion.div>

         <button
            onClick={() => setIsOpen((prev) => !prev)}
            className="cursor-pointer py-2 px-2 textBody-medium text-neutralBlack-500 flex items-center justify-center gap-2 hover:bg-neutralWhite-400 rounded-sm w-full mt-2"
         >
            <Image src={CommentIco} width={20} height={20} alt="Comments" />
            <span>Комментарии ({post.commentsCount})</span>
         </button>
      </div>
   );
};

export default ActionBlock;
