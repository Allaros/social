import {
   InfiniteData,
   useMutation,
   useQueryClient,
} from '@tanstack/react-query';
import { commentsApi } from '../api/comments';
import { ICreateComment } from '../types/comments.request';
import { normalizeApiError } from '@/shared/handlers/normalizeApiErrors';
import { toast } from 'sonner';
import { CommentResponse, CommentsPage } from '../types/comments.interface';

type PendingComment = Partial<CommentResponse> & {
   id: number;
   content: string;
   isPending: true;
};

type Author = {
   id?: number;
   name?: string;
   username?: string;
   avatarUrl?: string;
};

const useCreateComment = (author?: Author) => {
   const queryClient = useQueryClient();

   return useMutation({
      mutationFn: (payload: ICreateComment) =>
         commentsApi.createComment(payload),

      onMutate: async (variables) => {
         const { body, postId, parentId } = variables;

         if (parentId) return;

         await queryClient.cancelQueries({
            queryKey: ['comments', postId],
         });

         const previousData = queryClient.getQueryData(['comments', postId]);

         const tempComment: PendingComment = {
            id: Date.now(),
            content: body,
            createdAt: new Date().toISOString(),
            isDeleted: false,
            isPending: true,
            likesCount: 0,
            repliesCount: 0,
            isLiked: false,
            author: {
               id: author?.id ?? 0,
               username: author?.username ?? '@вы',
               name: author?.name ?? 'Вы',
               avatarUrl: author?.avatarUrl ?? undefined,
            },
         };

         queryClient.setQueryData(
            ['comments', postId],
            (old: InfiniteData<CommentsPage> | undefined) => {
               if (!old) return old;

               return {
                  ...old,
                  pages: [
                     {
                        ...old.pages[0],
                        data: [
                           tempComment as CommentResponse,
                           ...old.pages[0].data,
                        ],
                     },
                     ...old.pages.slice(1),
                  ],
               };
            }
         );
         return { previousData, tempId: tempComment.id };
      },

      onSuccess: (_data, variables) => {
         if (!variables.parentId) {
            setTimeout(() => {
               queryClient.invalidateQueries({
                  queryKey: ['comments', variables.postId],
               });
            }, 500);
         } else {
            queryClient.invalidateQueries({
               queryKey: ['replies', variables.parentId],
            });
         }
      },
      onError: (err, variables, context) => {
         if (context?.previousData) {
            queryClient.setQueryData(
               ['comments', variables.postId],
               context.previousData
            );
         }

         const error = normalizeApiError(err);

         toast(error.message);
      },
   });
};

export default useCreateComment;
