import {
   InfiniteData,
   useMutation,
   useQueryClient,
} from '@tanstack/react-query';
import { commentsApi } from '../api/comments';
import { toast } from 'sonner';
import { CommentsPage } from '../types/comments.interface';
import { normalizeApiError } from '@/shared/handlers/normalizeApiErrors';

export const useDeleteComment = (postId: number) => {
   const queryClient = useQueryClient();

   return useMutation({
      mutationFn: ({
         commentId,
         repliesCount,
      }: {
         commentId: number;
         repliesCount: number;
      }) => commentsApi.deleteComment(commentId),

      onMutate: async ({ commentId, repliesCount }) => {
         await queryClient.cancelQueries({ queryKey: ['comments', postId] });

         const previousData = queryClient.getQueryData(['comments', postId]);

         const isSoft = repliesCount > 0;

         queryClient.setQueryData(
            ['comments', postId],
            (oldData: InfiniteData<CommentsPage> | undefined) => {
               if (!oldData) return oldData;

               return {
                  ...oldData,
                  pages: oldData.pages.map((page: CommentsPage) => {
                     const updatedData = isSoft
                        ? page.data.map((comment) =>
                             comment.id === commentId
                                ? {
                                     ...comment,
                                     content: 'Комментарий удалён',
                                     isDeleted: true,
                                  }
                                : comment
                          )
                        : page.data.map((comment) =>
                             comment.id === commentId
                                ? { ...comment, isRemoving: true }
                                : comment
                          );

                     const updatedReplies: Record<number, any> = {};

                     Object.entries(page.replies).forEach(([key, comments]) => {
                        const parentId = Number(key);

                        updatedReplies[parentId] = isSoft
                           ? comments.map((comment) =>
                                comment.id === commentId
                                   ? {
                                        ...comment,
                                        content: 'Комментарий удалён',
                                        isDeleted: true,
                                     }
                                   : comment
                             )
                           : comments.map((comment) =>
                                comment.id === commentId
                                   ? { ...comment, isRemoving: true }
                                   : comment
                             );
                     });

                     return {
                        ...page,
                        data: updatedData,
                        replies: updatedReplies,
                     };
                  }),
               };
            }
         );

         return { previousData };
      },

      onError: (err, _variables, context) => {
         if (context?.previousData) {
            queryClient.setQueryData(
               ['comments', postId],
               context.previousData
            );
         }

         const error = normalizeApiError(err);
         toast.error(error.message);
      },
      onSettled: () => {
         setTimeout(() => {
            queryClient.invalidateQueries({
               queryKey: ['comments', postId],
               type: 'inactive',
            });
         }, 1000);
      },
   });
};
