export interface ICreateComment {
   body: string;
   postId: number;
   parentId?: number;
}

export interface IEditComment {
   body: string;
   postId: number;
   commentId: number;
}

export interface IGetComments {
   postId: number;
   cursor?: string;
   limit?: number;
}
