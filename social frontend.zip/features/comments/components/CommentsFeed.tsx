'use client';

import { FramedList } from '@/features/framer-animations/components/AnimatedList/FramedList';
import useGetComments from '../hooks/useGetComments';
import CommentItem from './CommentItem';
import CommentPlaceholder from './helpers/CommentPlaceholder';
import { useProfile } from '@/features/profile/hooks/useProfile';
import { FramedItem } from '@/features/framer-animations/components/AnimatedList/FramedItem';
import { CommentItemType } from '../types/comments.interface';

const CommentsFeed = ({
   postId,
   authorUsername,
}: {
   postId: number;
   authorUsername: string;
}) => {
   const { data, fetchNextPage, hasNextPage, isFetching } = useGetComments(
      postId,
      3
   );

   const profile = useProfile();

   if (!data || !data.pages.length) return <CommentPlaceholder />;

   const comments = data.pages.flatMap((page) => page.data);
   return (
      <FramedList layoutMode="items" preset="comments">
         {comments.map((comment: CommentItemType) =>
            !comment.isRemoving ? (
               <FramedItem key={comment.id} id={`${comment.id}`}>
                  <CommentItem
                     comment={comment}
                     postAuthorUsername={authorUsername}
                     currentProfileUsername={profile?.username}
                  />
               </FramedItem>
            ) : null
         )}
      </FramedList>
   );
};

export default CommentsFeed;
