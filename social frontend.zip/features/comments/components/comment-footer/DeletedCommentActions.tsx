import React from 'react';

const DeletedCommentActions = () => {
   return (
      <div>
         <button>Показать ответы</button>
      </div>
   );
};

export default DeletedCommentActions;
