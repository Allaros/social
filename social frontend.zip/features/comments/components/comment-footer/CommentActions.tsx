import { Heart, Trash2 } from 'lucide-react';
import Image from 'next/image';
import React from 'react';
import { CommentResponse } from '../../types/comments.interface';
import RedactIco from '@/public/icons/Write.svg';

const CommentActions = ({
   comment,
   setEdit,
   onDelete,
   isDeleting,
   authorUsername,
}: {
   comment: CommentResponse;
   setEdit: () => void;
   onDelete: () => void;
   isDeleting: boolean;
   authorUsername?: string;
}) => {
   return (
      <div className="flex justify-between items-center">
         <div>
            <button className="group flex items-center gap-1.5 cursor-pointer">
               <Heart
                  size={18}
                  className={` group-hover:text-red-500 transition-colors ${comment.isLiked ? 'text-red-500' : 'text-neutralBlack-500'}`}
                  fill={comment.isLiked ? '#fb2c36' : 'none'}
               />
               <span className="textLabel transition-colors">
                  {comment.likesCount}
               </span>
            </button>
         </div>
         <div className="flex items-center gap-2">
            {authorUsername && authorUsername === comment.author.username && (
               <>
                  <button
                     disabled={isDeleting}
                     onClick={onDelete}
                     className="p-1 rounded-full hover:bg-neutralWhite-500 cursor-pointer"
                  >
                     <Trash2 size={18} className="text-danger-800" />
                  </button>
                  <button
                     onClick={setEdit}
                     className="p-1 hover:bg-neutralWhite-500 cursor-pointer"
                  >
                     <Image
                        src={RedactIco}
                        width={18}
                        height={18}
                        alt="redact comment"
                     />
                  </button>
               </>
            )}
            <button className="textLabel-medium px-2 py-1 hover:bg-neutralWhite-500 rounded-sm cursor-pointer">
               Ответить
            </button>
         </div>
      </div>
   );
};

export default CommentActions;
