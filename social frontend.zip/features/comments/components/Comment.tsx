import React from 'react';
import { CommentResponse } from '../types/comments.interface';
import { AvatarImage } from '@/shared/components/ui/avatar';
import { Avatar, AvatarFallback } from '@radix-ui/react-avatar';
import UnknownIco from '@/public/icons/Incognito.svg';
import Image from 'next/image';
import { formatPostDate } from '@/shared/utils/dating';
import RedactIco from '@/public/icons/Write.svg';
import CommentActions from './comment-footer/CommentActions';
import { Heart, Trash2 } from 'lucide-react';

const Comment = ({
   comment,
   authorUsername,
   currentProfileId,
}: {
   comment: CommentResponse;
   authorUsername: string;
   currentProfileId?: number;
}) => {
   return (
      <div className="bg-neutralWhite-300 rounded-sm px-6 py-4 flex flex-col">
         <div className="flex gap-4 items-center mb-4">
            <Avatar>
               <AvatarImage
                  src={comment.author.avatarUrl}
                  width={48}
                  height={48}
                  alt="avatar"
                  className="max-w-12 max-h-12 rounded-full"
               />
               <AvatarFallback>
                  <Image
                     src={UnknownIco}
                     width={48}
                     height={48}
                     alt="avatar"
                  ></Image>
               </AvatarFallback>
            </Avatar>
            <div className="flex-1">
               <p className="h6 text-neutralBlack-900 flex items-center gap-2">
                  {comment.author.name}{' '}
                  {authorUsername === comment.author.username && (
                     <span className="bg-primary-900 rounded-sm block textLabel-medium px-2 text-neutralWhite-100 ">
                        Автор
                     </span>
                  )}
               </p>
               <p className="textLabel text-neutralBlack-800">
                  @{comment.author.username}
               </p>
            </div>
            <div className="self-start textLabel text-neutralBlack-500">
               {formatPostDate(comment.createdAt)}
            </div>
         </div>

         <div className="mb-2">
            <p className="textBody">{comment.content}</p>
         </div>
         <div className="flex justify-between items-center">
            <div>
               <button className="group flex items-center gap-1.5 cursor-pointer">
                  <Heart
                     size={18}
                     className={` group-hover:text-red-500 transition-colors ${comment.isLiked ? 'text-red-500' : 'text-neutralBlack-500'}`}
                     fill={comment.isLiked ? '#fb2c36' : 'none'}
                  />
                  <span className="textLabel transition-colors">
                     {comment.likesCount}
                  </span>
               </button>
            </div>
            <div className="flex items-center gap-2">
               {currentProfileId && currentProfileId === comment.author.id && (
                  <>
                     <button className="p-1 rounded-full hover:bg-neutralWhite-500 cursor-pointer">
                        <Trash2 size={18} className="text-danger-800" />
                     </button>
                     <button className="p-1 hover:bg-neutralWhite-500 cursor-pointer">
                        <Image
                           src={RedactIco}
                           width={18}
                           height={18}
                           alt="redact comment"
                        />
                     </button>
                  </>
               )}
               <button className="textLabel-medium px-2 py-1 hover:bg-neutralWhite-500 rounded-sm cursor-pointer">
                  Ответить
               </button>
            </div>
         </div>
      </div>
   );
};

export default Comment;
