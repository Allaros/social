'use client';

import { useProfile } from '@/features/profile/hooks/useProfile';
import {
   Avatar,
   AvatarFallback,
   AvatarImage,
} from '@/shared/components/ui/avatar';
import {
   Form,
   FormControl,
   FormField,
   FormItem,
} from '@/shared/components/ui/form';
import { CreateCommentSchema } from '@/shared/utils/validations';
import { zodResolver } from '@hookform/resolvers/zod';
import Image from 'next/image';
import { useForm } from 'react-hook-form';
import z from 'zod';
import UnknownIco from '@/public/icons/Incognito.svg';
import { SendHorizontal } from 'lucide-react';
import useCreateComment from '../../hooks/useCreateComment';

type FormFields = z.infer<typeof CreateCommentSchema>;

const CreateCommentForm = ({ postId }: { postId: number }) => {
   const profile = useProfile();
   const { mutate: createComment, isPending } = useCreateComment({
      id: profile?.id,
      name: profile?.name,
      username: profile?.username,
      avatarUrl: profile?.avatarUrl,
   });

   const form = useForm<FormFields>({
      resolver: zodResolver(CreateCommentSchema),
      defaultValues: {
         body: '',
      },
   });

   const onSubmit = (data: FormFields) => {
      createComment({ body: data.body, postId });
      console.log(data);
   };

   return (
      <div className="flex items-center gap-6 py-4">
         <Avatar className="self-start">
            <AvatarImage
               src={profile?.avatarUrl}
               width={48}
               height={48}
               alt="avatar"
            />
            <AvatarFallback>
               <Image src={UnknownIco} width={48} height={48} alt="avatar" />
            </AvatarFallback>
         </Avatar>
         <Form {...form}>
            <form
               className="flex-1 flex items-end gap-2"
               onSubmit={form.handleSubmit(onSubmit)}
            >
               <FormField
                  control={form.control}
                  name="body"
                  render={({ field }) => (
                     <FormItem className="flex-1">
                        <FormControl>
                           <textarea
                              placeholder="Поделитесь своими мыслями..."
                              className="border w-full rounded-sm px-6 py-2.5 resize-none overflow-hidden border-neutralWhite-400 focus:border-neutralBlack-300 outline-none"
                              rows={1}
                              {...field}
                              onInput={(e) => {
                                 const target = e.target as HTMLTextAreaElement;
                                 target.style.height = 'auto';
                                 target.style.height =
                                    target.scrollHeight + 'px';
                              }}
                           />
                        </FormControl>
                     </FormItem>
                  )}
               />
               <button
                  disabled={isPending}
                  type="submit"
                  className="text-neutralBlack-500 p-1 mb-1.5 cursor-pointer hover:bg-neutralWhite-400 transition-colors rounded-sm"
               >
                  <SendHorizontal></SendHorizontal>
               </button>
            </form>
         </Form>
      </div>
   );
};

export default CreateCommentForm;
