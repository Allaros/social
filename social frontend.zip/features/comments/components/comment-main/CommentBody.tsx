import React from 'react';

const CommentBody = ({
   content,
   isDeleted,
}: {
   content: string | null;
   isDeleted: boolean;
}) => {
   if (isDeleted) {
      return (
         <div className="textBody text-neutralBlack-500 py-4 italic">
            Комментарий удалён
         </div>
      );
   }

   return <div className="textBody text-neutralBlack-900 py-4">{content}</div>;
};

export default CommentBody;
