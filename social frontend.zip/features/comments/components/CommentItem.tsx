import React, { useState } from 'react';
import { CommentItemType, CommentResponse } from '../types/comments.interface';
import CommentAuthor from './comment-header/CommentAuthor';
import CommentEditForm from './forms/CommentEditForm';
import CommentBody from './comment-main/CommentBody';
import CommentActions from './comment-footer/CommentActions';
import { useDeleteComment } from '../hooks/useDeleteComment';
import DeletedCommentActions from './comment-footer/DeletedCommentActions';
import { motion } from 'framer-motion';

const CommentItem = ({
   comment,
   postAuthorUsername,
   currentProfileUsername,
}: {
   comment: CommentItemType;
   postAuthorUsername: string;
   currentProfileUsername?: string;
}) => {
   const [isEditing, setIsEditing] = useState(false);

   const { mutate: deleteComment, isPending: isDeleting } = useDeleteComment(
      comment.postId
   );

   if (comment.isPending) {
      return (
         <div className="bg-neutralWhite-300 py-4 px-6 rounded-sm opacity-70">
            <CommentAuthor
               comment={comment as any}
               postAuthorUsername={postAuthorUsername}
            />

            <CommentBody
               content={comment.content}
               isDeleted={comment.isDeleted}
            />

            <div className="text-sm text-neutralBlack-400">Отправка...</div>
         </div>
      );
   }

   return (
      <div className="bg-neutralWhite-300 py-4 px-6 rounded-sm">
         <CommentAuthor
            comment={comment}
            postAuthorUsername={postAuthorUsername}
         />
         {isEditing ? (
            <CommentEditForm
               comment={comment}
               onCancel={() => setIsEditing(false)}
            />
         ) : (
            <>
               <CommentBody
                  content={comment.content}
                  isDeleted={comment.isDeleted}
               />
               {!comment.isDeleted ? (
                  <CommentActions
                     comment={comment}
                     authorUsername={currentProfileUsername}
                     setEdit={() => setIsEditing(true)}
                     onDelete={() =>
                        deleteComment({
                           commentId: comment.id,
                           repliesCount: comment.repliesCount,
                        })
                     }
                     isDeleting={isDeleting}
                  />
               ) : (
                  <DeletedCommentActions />
               )}
            </>
         )}
      </div>
   );
};

export default CommentItem;
