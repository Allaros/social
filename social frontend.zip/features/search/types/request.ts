export interface IDropdownSearch {
   query: string;
}

export interface IGetSearchResults {
   query: string;
   type: number;
   limit: number;
   page: number;
}
