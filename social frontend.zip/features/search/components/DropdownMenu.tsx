import { useDropdownSearch } from '../hooks/useDropdownSearch';
import { DropdownItem, sectionOrder, sectionTitles } from '../types/responce';

const DropdownMenu = ({
   query,
   className,
}: {
   query: string;
   className: string;
}) => {
   const { data, isLoading } = useDropdownSearch(query);
   const hasResults = sectionOrder.some((section) => data[section].length > 0);

   if (!hasResults) return null;

   return (
      <div className={`${className} card py-2 px-4`}>
         {sectionOrder.map((section) => {
            const items = data[section];
            console.log(data['profiles'], section);
            if (!items.length) return null;

            return (
               <div key={section}>
                  <div className="text-xs text-neutral-500 mb-2">
                     {sectionTitles[section]}
                  </div>

                  {items.map((item: DropdownItem) => (
                     <div key={item.id}>
                        <div>{item.primary}</div>
                        <div>{item.secondary}</div>
                     </div>
                  ))}
               </div>
            );
         })}
      </div>
   );
};

export default DropdownMenu;
