import { profileApi } from '@/features/profile/api/profile';
import { useQuery, UseQueryResult } from '@tanstack/react-query';

export const useGetProfile = (
   slug: string
): UseQueryResult<ProfileResponce, Error> => {
   return useQuery({
      queryKey: ['profile', slug],
      queryFn: () => profileApi.getProfile({ slug }),
      enabled: !!slug,
   });
};
