import React from 'react';

const PostsCard = () => {
   return <div className="card">PostsCard</div>;
};

export default PostsCard;
