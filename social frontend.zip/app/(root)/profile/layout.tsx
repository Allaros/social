import UserCard from '@/features/user/components/cards/UserCard';
import React from 'react';

const ProfileLayout = ({ children }: { children: React.ReactNode }) => {
   return (
      <div className="pt-32 grid grid-cols-[3fr_9fr] items-start gap-8">
         <UserCard />
         {children}
      </div>
   );
};

export default ProfileLayout;
