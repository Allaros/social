'use client';

import GlobalDropHandler from '@/shared/components/GlobalDropHandler';
import RootHeader from '@/features/feed/components/navigation/RootHeader';
import AuthGuard from '@/features/auth/providers/AuthGuard';

const MainLayout = ({ children }: { children: React.ReactNode }) => {
   return (
      <AuthGuard>
         <div>
            <RootHeader />
            <GlobalDropHandler />
            {children}
         </div>
      </AuthGuard>
   );
};

export default MainLayout;
