'use client';

import Loader from '@/features/loader/components/Loader';
import DynamicForm, {
   FieldConfig,
} from '@/features/auth/components/forms/DynamicForm';
import ROUTES from '@/shared/constants/routes';
import { useChangePass } from '@/features/auth/hooks/useChangePass';
import { ResetPasswordSchema } from '@/shared/utils/validations';
import { useRouter, useSearchParams } from 'next/navigation';
import { toast } from 'sonner';
import z from 'zod';

const ResetPassword = () => {
   const router = useRouter();
   const { mutate: changePass, isPending } = useChangePass();
   const searchParams = useSearchParams();

   const handleSubmit = (data: z.infer<typeof ResetPasswordSchema>) => {
      const token = searchParams.get('recovery');
      if (!token) {
         toast.error('Токен восстановления отсутствует или недействителен');
         router.replace(ROUTES.auth.forgotPass);
         return null;
      }
      const { confirmPassword, password } = data;

      const payload: IChangePass = {
         password,
         token,
      };
      changePass(payload);
   };

   return (
      <>
         <h5 className="h5">Восстановление пароля</h5>
         <p className="textBody text-neutralBlack-500 text-center mb-4">
            Введите email чтобы сбросить пароль и получить доступ к аккаунту
         </p>
         <DynamicForm
            schema={ResetPasswordSchema}
            fields={
               [
                  { name: 'password', label: 'Новый пароль', type: 'password' },
                  {
                     name: 'confirmPassword',
                     label: 'Подтверждение пароля',
                     type: 'password',
                  },
               ] as FieldConfig<typeof ResetPasswordSchema>[]
            }
            onSubmit={handleSubmit}
            btnDisabled={isPending}
         ></DynamicForm>
      </>
   );
};

export default ResetPassword;
